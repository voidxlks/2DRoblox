# 2D Python Roblox

A simple 2D Roblox-style sandbox game made with Python and Pygame.

## Controls
W - Move Up
A - Move Left
S - Move Down
D - Move Right

## Install

pip install -r requirements.txt

## Run

python main.py
