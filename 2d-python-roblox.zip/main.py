import pygame
from player import Player
from world import World

pygame.init()

WIDTH = 800
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2D Python Roblox")

clock = pygame.time.Clock()

player = Player(400, 300)
world = World()

running = True

while running:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    player.move(keys)

    screen.fill((135, 206, 235))

    world.draw(screen)
    player.draw(screen)

    pygame.display.update()

pygame.quit()
